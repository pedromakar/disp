console.log("js funcionando em arquivo externo (arquivo .js)!");
window.alert("js funcionando !");

//o alert funciona no browser e NAO no console
